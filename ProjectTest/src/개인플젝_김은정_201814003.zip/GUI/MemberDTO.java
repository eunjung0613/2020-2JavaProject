package GUI;

public class MemberDTO {
	private String id;
	private String pw;
	private int account;
	private int money;
	
	public String getId() {
		return id;
	}
	public void setId(String i) {
		this.id = i;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public int getAccount() {
		return account;
	}
	public void setAccount(int account) {
		this.account = account;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	
	
}
