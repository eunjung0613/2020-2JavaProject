package GUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.sql.*;

public class MainGui {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Login();
	}
}
